Code from the article "A new self-made digital slide scanner and
microscope for imaging and quantification of
fluorescent microspheres" 
by
William Henning, Julie Bjerglund Andersen, Liselotte Hoejgaard, Gorm Greisen, Ian Law, Anders Thorseth,
Anders Nymark Christensen

Finds microspheres (or other small coloured blobs) in images.